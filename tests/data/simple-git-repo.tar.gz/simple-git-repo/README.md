# Simple Git Repo #

This is a simple git repo to be used as a pytest fixture.

This repository has:
  - multiple branches: `master`, `fork1`, `fork2`
  - simple tags: `initial_commit`, `list_of_refs`
  - extra direct ref to a version of `README.md`: `direct_README`
  - symbolic ref to `fork1`: `sym_alias_fork1`

